# Outlook and Gmail setup

Use delegated authorization for the authenticated user's own mailbox. Store OAuth client secrets in the Copilot connector's managed secret store, never in this package.

## Microsoft Graph

1. Create a Microsoft Entra app registration.
2. Use the redirect URI supplied by the Copilot connector configuration.
3. Add delegated permissions: `User.Read`, `Mail.ReadWrite`, and `offline_access` only if refresh is required.
4. Configure actions for listing/searching/getting messages, listing/creating folders, and moving messages under `/me`.
5. Test with non-sensitive messages and a test folder.

Required endpoint families:
- `GET /me/messages`
- `GET /me/messages/{id}`
- `GET /me/mailFolders`
- `POST /me/mailFolders`
- `POST /me/messages/{id}/move`

## Gmail API

1. Create a Google Cloud project and enable Gmail API.
2. Configure the OAuth consent screen and test user.
3. Create an OAuth web client with the Copilot connector redirect URI.
4. Request delegated `https://www.googleapis.com/auth/gmail.modify`.
5. Configure list/get messages, list/create labels, and modify-message-label actions.
6. Test with non-sensitive messages and a test label.

Required endpoint families:
- `GET /gmail/v1/users/me/messages`
- `GET /gmail/v1/users/me/messages/{id}`
- `GET /gmail/v1/users/me/labels`
- `POST /gmail/v1/users/me/labels`
- `POST /gmail/v1/users/me/messages/{id}/modify`

Gmail mailbox-reading scopes may be restricted and can require Google verification or security assessment outside limited testing.

## SharePoint and OneDrive

Register the Microsoft Graph actions described in `repository-connectors.md`. Start with delegated `Files.Read` for the user's OneDrive. Use `Files.Read.All` or `Sites.Read.All` only when scanning explicitly approved SharePoint/OneDrive content accessible to the user. Add corresponding write permissions only for authorized remediation.

## Google Drive

Enable Google Drive API and, where used, Drive Labels API. Configure delegated OAuth using the narrowest scope that reaches the approved files. Existing-drive audits generally require broader read access than `drive.file`; remediation may require write access. Review Google's restricted-scope verification requirements.

## Box

Create a Box OAuth 2.0 application. Enable read scope for discovery and write scope only for approved metadata/move actions. Authorize as the user and avoid enterprise-wide service-account authority.

## Other online repositories

Implement the generic contract from `repository-connectors.md`. Store credentials in managed connector secret stores. Never place tokens, keys, connection strings, bucket credentials, or service-account material in the skill package.
