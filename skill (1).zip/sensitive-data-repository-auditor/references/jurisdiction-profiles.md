# Jurisdiction and framework profiles

These profiles guide data discovery, not legal conclusions. A single finding may map to several profiles.

## Core identity and confidential data

Detect direct identifiers and risky combinations: full name, personal email/phone, home address, date/place of birth, signature, username, customer/employee/student IDs, tax identifiers, government IDs, passport, driver's licence, vehicle registration, immigration/citizenship records, benefits records, background checks, precise geolocation, account credentials, private keys, and recovery codes.

## European Union and EEA

### GDPR personal data

Identifiers, online identifiers, location data, and information relating to an identifiable natural person.

### GDPR Article 9 special categories

Racial or ethnic origin; political opinions; religious or philosophical beliefs; trade-union membership; genetic data; biometric data used for unique identification; health data; sex life; sexual orientation.

### GDPR Article 10

Personal data relating to criminal convictions and offences.

Include national identity, tax, social-insurance, passport, residence-permit, and health-insurance identifiers using country-aware context. Do not infer nationality or special-category status.

## United States federal

### Identity and consumer information

SSN, ITIN, ATIN, EIN when tied to a person, passport, military ID, state ID/driver's licence, immigration identifiers, financial account/routing numbers, credit reports, authentication data, and identity documents.

### HIPAA-oriented PHI profile

Use only as a discovery aid for individually identifiable health information: patient/account/medical-record identifiers, diagnoses, treatment, prescriptions, lab results, claims, insurance/member IDs, provider communications, dates tied to care, images, biometrics, and genetic information. Do not label content `HIPAA-regulated` unless covered-entity/business-associate context is established.

### GLBA-oriented financial profile

Customer financial records, account numbers, transaction history, credit data, loan/mortgage records, income, assets, tax records, and authentication information. Do not assert GLBA applicability without financial-institution/service context.

### FERPA-oriented education profile

Student IDs, grades, transcripts, discipline, disability/accommodation, financial aid, attendance, and education records tied to a student. Do not assert FERPA applicability without education-record context.

### CJIS and criminal-justice profile

Criminal-history, case, arrest, warrant, fingerprint, biometric, and law-enforcement identifiers. Treat as high risk; applicability depends on agency and system context.

### Federal agency CUI-related profile

Flag contract-marked or context-supported CUI categories, export-controlled technical data, procurement-sensitive data, and federal personnel information. Do not infer CUI from sensitivity alone; require markings or strong contract/program context.

## United States states and territories

Apply a common sensitive-personal-data taxonomy spanning comprehensive state privacy laws and breach-notification definitions:

- State-issued driver's licence and identification-card numbers from any state or territory.
- SSN/tax IDs, passport, financial account plus access data, medical/health-insurance information, biometrics/genetics, precise geolocation, racial/ethnic origin, religion, citizenship/immigration status, sexual orientation/sex life, union membership, contents of communications, children's data, and account credentials.
- California profile additionally flags CCPA/CPRA-sensitive classes such as government identifiers, account login with credentials, precise geolocation, protected characteristics, communications content, genetic data, biometric identification, health, and sex-life/orientation data.

State laws differ. Report matching state profiles only when residence, business scope, sender/recipient context, or explicit jurisdictional metadata supports the mapping; otherwise report `US state-sensitive category, state undetermined`.

## Canada federal

### PIPEDA-oriented profile

Personal information about an identifiable individual. Treat medical and income records as inherently high sensitivity and apply contextual sensitivity to all other personal information. Include SIN, passport, immigration, tax, banking, credit, employment, education, health, biometric, genetic, online identifier, location, and credential data.

### Canadian public-sector and regulated contexts

Flag Protected/Designated markings, security clearance information, federal personnel records, taxpayer data, benefits records, immigration/citizenship information, health data, and law-enforcement information. Do not infer a Government of Canada security classification from content alone.

## Canada provincial and territorial

Support province/territory-aware identifiers and records:

- Health card and provincial health-plan numbers.
- Driver's licence and provincial/territorial ID numbers.
- Birth, death, marriage, adoption, and vital-statistics records.
- Provincial tax, benefits, workers' compensation, education/student, employment, child/family services, and justice records.

Private-sector profiles include Alberta PIPA, British Columbia PIPA, and Quebec's private-sector privacy law as amended by Law 25. Health-sector profiles include applicable provincial health-information statutes, such as Ontario PHIPA, Alberta HIA, and comparable provincial/territorial regimes. Report the province only when context supports it.

Quebec profile: personal information that directly or indirectly identifies a natural person; increase risk for medical, biometric, financial, identity, minor, and combination-risk data.

## PCI DSS

### Cardholder data

- Primary account number (PAN), validated with context and checksum.
- Cardholder name, expiration date, and service code when associated with PAN.

### Sensitive authentication data

- Full track data or equivalent chip/stripe data.
- Card verification code/value (CVV, CVC, CID).
- PIN and PIN blocks.

Treat exposed sensitive authentication data as critical. Never display it. Mask PAN to last four only. Do not call a payment token a PAN unless format and context support that conclusion.

## Credentials and secrets

Passwords, recovery codes, API keys, OAuth/bearer tokens, private keys, cloud access keys, client secrets, connection strings, database credentials, SAS tokens, webhooks, SSH keys, and signing material. Follow the same non-validation and redaction philosophy as the Email Secret Auditor.
