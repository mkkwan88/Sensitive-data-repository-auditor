---
name: sensitive-data-repository-auditor
description: scan the authenticated user's authorized outlook and gmail mailboxes plus sharepoint, onedrive, google drive, box, and other configured online file repositories for regulated or sensitive data under configurable european union, united states federal and state, canadian federal and provincial, payment card, health, identity, financial, credential, and organizational data profiles. produce redacted findings and perform user-approved remediation by moving outlook messages to a designated folder or applying a gmail label. use when the user asks to audit email for pii, phi, payment data, government identifiers, personal data, special-category data, credentials, or regulated information.
---
# Sensitive Data Repository Auditor

Audit only repositories the authenticated user owns or is explicitly authorized to access: Outlook, Gmail, SharePoint, OneDrive, Google Drive, Box, and other configured file repositories. This skill performs discovery and triage; it does not determine legal applicability, declare a breach, or certify compliance.

## Required tools

Require configured delegated connector actions for:

- Outlook: list/create folders, list/search/get messages, move messages.
- Gmail: list/create labels, list/search/get messages, modify labels.
- SharePoint and OneDrive: enumerate authorized sites/drives, search/list/download supported files, read metadata/permissions, and move or label files when explicitly approved.
- Google Drive: list/search/export/download supported files, read permissions/labels, and apply approved Drive labels or move files.
- Box: list/search/download supported files, read collaborations/shared links/metadata, and apply approved metadata or move files.
- Other repositories: use the generic connector contract in `references/repository-connectors.md`.

If unavailable, stop for that provider and direct the user to `references/setup.md`. Never request OAuth secrets or mailbox credentials in chat.

## Workflow

1. Confirm repositories and roots/sites/drives/folders, date range, maximum items, jurisdiction/data profiles, file types, and whether email attachments and file versions are included. Defaults: both providers, last 90 days, 500 messages per provider, `core-identity`, `credentials`, and `payment-card`; attachments excluded.
2. Load `references/jurisdiction-profiles.md`, `references/detection-rules.md`, and `references/source-register.md`.
3. Inventory metadata first. Search indexed content where supported, then fetch message bodies or file content only for candidates. For repositories without content search, enumerate within the approved root and enforce item/byte limits.
4. Normalize plain text; strip HTML controls, signatures, quoted history, tracking URLs, and invisible content while preserving tables and field labels.
5. Detect values using pattern, checksum where applicable, context, proximity, and combination risk. A pattern match alone is not a regulatory conclusion.
6. Deduplicate by repository, stable item ID/version, data class, and one-way fingerprint. Do not scan the same binary version repeatedly.
7. Produce a redacted report and proposed remediation. Do not mutate messages yet.
8. Require explicit approval of finding numbers/message IDs and exact destination.
9. Ensure the destination, label, or metadata classification exists; remediate only approved items; preserve version history where supported; and verify every mutation.

## Risk model

Score each finding:

- Critical: full sensitive authentication data, private credentials, or a high-risk identity bundle such as full name plus government ID plus date of birth.
- High: validated payment card number, government identifier, medical/health record tied to a person, biometric/genetic data, exact account credentials, or multiple linked identifier classes.
- Medium: one sensitive identifier with incomplete context, financial/account information without access credentials, precise location, employment/education record, or confidential legal/HR content tied to a person.
- Low: ambiguous pattern, public business contact information, test data, masked value, or context-free identifier.

Never call a message non-compliant solely because it contains sensitive data. Never call a detected occurrence a breach without evidence of unauthorized disclosure.

## Mandatory redaction

- Passwords, recovery codes, CVV/CVC/CID, PINs, private keys, authentication tokens: show only `[REDACTED]` and length/type.
- Government IDs, account numbers, health numbers, and payment cards: show only last four characters when necessary.
- Names, addresses, dates of birth, medical details, ethnicity, religion, sexual orientation, union membership, political opinion, criminal history, biometric/genetic data: minimize or generalize; do not reproduce the underlying detail.
- Use SHA-256 fingerprints locally for deduplication only. Never persist raw values or include them in logs, filenames, reports, or remediation arguments.

## Report format

Return:

1. Scope, profiles, date range, message limits, attachments status, and unscanned content.
2. Counts by provider, risk, data class, and relevant profile.
3. Findings table: number, repository, path/site/drive, created date/by, last modified date/by, last opened date/by when authoritative activity data is available, owner or sender, item name or subject, data classes, matching profiles, risk, redacted evidence, item link/ID, sharing exposure, recommended handling.
4. Combination-risk findings where multiple data types occur together.
5. False-positive and applicability caveats.
6. Proposed remediation requiring explicit approval.

## CSV report export

When the user asks to export, download, save, or generate a report, load `references/csv-report.md` and create a UTF-8 CSV using its exact schema. Include filepath, creator, last modifier, and last opener only from authoritative metadata or audit/activity APIs. Never infer opened-by data. Mark unavailable or unauthorized fields explicitly. Apply redaction and spreadsheet formula-injection protection before writing the CSV.

## Remediation

Load `references/remediation.md` before mutations.

- Outlook: move approved messages to the approved folder using delegated access.
- Gmail: apply the approved label using delegated access. Gmail uses labels, not Outlook categories.
- SharePoint/OneDrive: apply an approved retention/sensitivity-compatible metadata field or move within an approved library/folder; never break inheritance or change sharing by default.
- Google Drive: apply an approved Drive label or move within an approved drive/folder.
- Box: apply an approved metadata template/value or move within an approved folder.
- Generic repositories: prefer reversible labels/tags/metadata; moving requires an explicit destination and approval.
- Suggested destinations: Outlook `Sensitive Data - Review`; Gmail `Sensitive Data/Review`.
- Never delete, forward, reply, export, or use detected information.
- Require a second explicit approval for more than 25 messages.

## Guardrails

- Scope every scan to explicit authorized roots. No tenant-wide, domain-wide, enterprise-wide, public-cloud-bucket, or other-user scan without a separately approved governance model and least-privilege connector.
- Do not infer protected traits from names, language, photographs, or associations.
- Do not test credentials, cards, bank accounts, insurance numbers, or identity documents.
- Do not automatically notify regulators or affected individuals.
- Treat legal profiles as classification aids. Applicability depends on organization, role, processing activity, location, contract, and context.
- Mark encrypted, malformed, unsupported, or password-protected items as `not scanned`.
