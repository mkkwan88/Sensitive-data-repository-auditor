# Detection rules

## Detection layers

1. Candidate search terms and metadata.
2. Structured patterns.
3. Checksum or structural validation where safe and applicable.
4. Nearby labels and semantic context.
5. Combination-risk analysis.
6. Placeholder/test-data suppression.

## High-value validators

- Payment cards: PAN-like length, payment context, and Luhn validation. Never retain or show more than last four.
- Canadian SIN: nine digits, SIN context, and checksum. Suppress known invalid/test sequences.
- US SSN/ITIN: structural exclusions plus nearby SSN/ITIN/tax context. Pattern alone is insufficient.
- Government IDs: require jurisdictional label, document type, or a recognized issuer-specific format.
- Health IDs: require province/state/insurer/health context; avoid treating arbitrary account numbers as health data.
- IBAN and bank accounts: structure/checksum where defined plus banking/payment context.
- Email/phone/address: report alone only when scan policy requests basic PII; otherwise use them to raise combination risk.
- Credentials: require recognized format or a secret label plus credential-shaped value.

## Combination risk

Raise risk when one message contains linked combinations such as:

- Name + government ID + date of birth.
- Name + health information + health/member/record ID.
- PAN + cardholder name/expiry; any CVV/PIN/track data is critical.
- Bank account + routing/transit + identity data.
- Username + password/recovery code/token.
- Student ID + grades/discipline/accommodation.
- Employee ID + compensation/tax/medical/disciplinary data.

## False-positive suppression

Suppress or lower confidence for masked values, documentation/examples, lorem/test/dummy/sample markers, public business contact data, email Message-IDs, order/tracking numbers, UUIDs, hashes, unsubscribe tokens, public keys, certificate bodies without private material, and random numeric strings without labels.

## Candidate terms

Use localized and jurisdiction-aware terms, including equivalents for: SSN, SIN/NAS, tax ID, passport, licence/license, health card, patient, medical record, diagnosis, prescription, claim, insurance member, bank account, routing, transit, IBAN, card number, PAN, CVV/CVC/CID, PIN, student ID, transcript, payroll, salary, background check, biometric, genetic, citizenship, immigration, union, religion, political opinion, criminal record, password, API key, secret, token, private key, recovery code.

## Attachments

Excluded by default. If approved, use malware-safe text extraction for plain text, CSV, JSON, XML, Office documents, and PDFs. Never execute macros, scripts, archives, or binaries. Mark encrypted/password-protected content `not scanned`.
