# File processing policy

## Supported by default

Plain text, CSV, JSON, XML, YAML, source/config files, PDF, and Office documents. Google Docs/Sheets/Slides must be exported to a safe text-oriented format. Limit scanning to the approved roots, item count, and byte budget.

## Excluded by default

Archives, encrypted/password-protected files, executables, disk images, database dumps, PST/OST/MBOX, macro execution, scripts requiring execution, media OCR, and images. They may be inventoried as `not scanned` with size/type/reason.

## Safety

- Never execute active content, macros, formulas, embedded objects, or links.
- Perform archive expansion only in an isolated extractor, with depth, file-count, compression-ratio, and total-byte limits.
- Scan only a downloaded working copy; never modify the source during detection.
- Record item version/eTag before remediation and abort on conflict.
- Minimize extracted text and discard it immediately after classification.

## Recommended limits

Defaults per run: 5,000 items, 2 GB total fetched content, 100 MB per file, 10 minutes per repository, and latest version only. The user may reduce these limits. Higher limits require explicit approval and connector-side throttling/backoff.
