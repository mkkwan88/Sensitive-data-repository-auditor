# Remediation

## Outlook

Suggested folder: `Sensitive Data - Review`.

1. List folders and match the exact approved name.
2. If absent, obtain approval to create it.
3. Move only approved message IDs with Microsoft Graph delegated `Mail.ReadWrite`.
4. Record the returned message ID because a move can change it.
5. Verify the destination folder for every moved message.

## Gmail

Suggested label: `Sensitive Data/Review`.

1. List labels and match the exact approved name.
2. If absent, obtain approval to create it.
3. Add the label with Gmail `users.messages.modify` and delegated `gmail.modify`.
4. Do not remove `INBOX`, archive, trash, or delete unless separately requested and supported by policy.
5. Verify the label ID on every modified message.

## Recommended handling

- Credentials/secrets: rotate or revoke through the authoritative provider and review audit logs.
- Payment data: notify the organization's payment-security owner; do not reproduce SAD or full PAN.
- Health, identity, or financial data: restrict access, preserve evidence, and follow the organization's privacy/incident process.
- Potential regulated disclosure: preserve facts and route to privacy, legal, security, or compliance personnel. Do not automatically declare or report a breach.

## SharePoint and OneDrive

Prefer reversible metadata or an existing approved Microsoft Purview sensitivity label. If moving, use an approved folder in the same library/drive and preserve version history. Do not change sharing links, ACLs, retention labels, records status, or legal holds.

## Google Drive

Prefer Drive Labels API structured labels. Moving means updating parents inside the approved drive boundary. Do not change permissions, link sharing, ownership, or download restrictions.

## Box

Prefer an enterprise metadata template. Moving must remain within the approved Box scope. Do not change collaborations, shared links, retention, or legal holds.

## Other repositories

Use tags/labels/metadata when reversible. If no safe remediation action exists, generate a report-only disposition and require the user to remediate in the repository's native administration interface.
