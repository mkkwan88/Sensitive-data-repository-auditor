# Sensitive Data Repository Auditor

A Microsoft Copilot skill that scans authorized Outlook and Gmail mailboxes plus SharePoint, OneDrive, Google Drive, Box, and other configured online repositories for sensitive and potentially regulated data, presents redacted findings, and supports user-approved remediation.

## Coverage

- European Union/EEA: GDPR personal data, Article 9 special categories, and Article 10 criminal-conviction/offence data.
- United States federal: identity data plus HIPAA-, GLBA-, FERPA-, CJIS-, and CUI-oriented discovery profiles.
- United States states and territories: common sensitive-personal-data classes, state-issued identifiers, breach-notification identifiers, and a California CCPA/CPRA profile.
- Canada federal: PIPEDA-oriented personal and sensitive information, SIN, tax, immigration, financial, employment, education, health, biometric, and credential data.
- Canada provinces and territories: health-card, driver's-licence, provincial ID, vital-statistics, education, benefits, justice, and province-aware privacy/health profiles including Alberta, British Columbia, Quebec, and Ontario.
- PCI DSS: cardholder data and sensitive authentication data.
- Credentials and secrets: passwords, recovery codes, API keys, tokens, private keys, connection strings, and similar authentication material.

Coverage is implemented as classification profiles, not legal opinions. Exact applicability depends on the organization, role, processing activity, jurisdiction, contract, and context.

## Repository coverage

- Outlook and Gmail
- SharePoint document libraries and OneDrive
- Google Drive, including supported Google Workspace file exports
- Box
- Extensible connector contract for Dropbox, Egnyte, Citrix ShareFile, OpenText, AWS S3, Azure Blob Storage, Google Cloud Storage, GitHub, GitLab, and Confluence

## CSV reporting

The skill can export a detailed UTF-8 CSV with repository, site/drive/container, canonical filepath, filename, IDs and links, file type and size, created date/by, last modified date/by, last opened date/by when an authorized audit source exists, owner, sharing exposure, detected data classes, regulatory profiles, risk, confidence, redacted evidence, version/eTag, scan status, recommendations, and remediation status.

`Last opened by` is never inferred. It is populated only from Microsoft 365 audit/activity data, Google Drive Activity or Workspace audit data, Box enterprise events, or an equivalent authoritative repository event API. Otherwise the report records `not_available` or `not_authorized`.

The export protects against spreadsheet formula injection and never includes complete sensitive values.

## Remediation

- Outlook: move approved messages to a designated folder, suggested `Sensitive Data - Review`.
- Gmail: apply an approved label, suggested `Sensitive Data/Review`.
- SharePoint/OneDrive: apply approved metadata or move to a review folder without changing permissions.
- Google Drive: apply a Drive label or move to an approved folder.
- Box: apply metadata or move to an approved folder.
- Other repositories: reversible labels/tags/metadata where supported; otherwise report-only.
- Every mutation requires explicit user approval, and bulk operations over 25 messages require a second approval.

## Safety principles

- Delegated access to the user's own mailbox only.
- Redaction and data minimization by default.
- No credential/card/account validation.
- No automatic deletion, forwarding, exporting, breach declaration, or regulator notification.
- Attachments excluded unless explicitly authorized and processed with malware-safe extraction.

## Installation

1. Import `skill.zip` into the Copilot environment that supports custom skills.
2. Configure Microsoft Graph and Gmail API connectors by following `references/setup.md`.
3. Store OAuth secrets only in managed connector secret stores.
4. Map connector operations to the required list/get/create/move/modify actions.
5. Test with synthetic, non-sensitive messages before production use.

## Example prompts

- `Scan my Outlook email from the last 90 days for Canadian, US, EU, and PCI sensitive data.`
- `Check Gmail for health information, government IDs, payment cards, and credentials.`
- `Show high and critical findings only, with all values redacted.`
- `Move approved Outlook findings to Sensitive Data - Review.`
- `Apply Sensitive Data/Review to approved Gmail messages.`

## Files

- `SKILL.md`: workflow and guardrails.
- `references/jurisdiction-profiles.md`: sensitive-data profiles.
- `references/detection-rules.md`: validation and false-positive handling.
- `references/remediation.md`: approved Outlook/Gmail actions.
- `references/setup.md`: connector setup.
- `references/repository-connectors.md`: provider-specific and generic connector contract.
- `references/file-processing.md`: safe extraction, file-type, version, and size limits.
- `references/csv-report.md`: exact CSV schema, audit-field rules, redaction, and formula-injection protection.
- `references/source-register.md`: authoritative sources used to maintain the profiles.
- `LICENSE`: MIT License.
