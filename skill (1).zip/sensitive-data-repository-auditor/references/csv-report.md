# CSV report specification

Generate a UTF-8 CSV report when requested. Use RFC 4180-compatible quoting, a header row, ISO 8601 UTC timestamps, and one row per finding per item. Never place raw sensitive values in the CSV.

## Required columns

Use this exact column order:

1. `finding_id`
2. `repository`
3. `site_drive_or_container`
4. `filepath`
5. `item_name`
6. `item_id`
7. `web_url`
8. `mime_type`
9. `size_bytes`
10. `created_at`
11. `created_by`
12. `last_opened_at`
13. `last_opened_by`
14. `last_modified_at`
15. `last_modified_by`
16. `owner`
17. `sharing_exposure`
18. `external_sharing`
19. `data_classes`
20. `regulatory_profiles`
21. `risk`
22. `confidence`
23. `redacted_evidence`
24. `version_or_etag`
25. `scan_status`
26. `scan_error`
27. `recommended_action`
28. `remediation_status`
29. `remediation_destination_or_label`
30. `scanned_at`

## Field rules

- `filepath`: canonical repository path when available. For email, use a virtual path such as `Outlook/Inbox/<subject>` or `Gmail/<label>/<subject>`.
- `created_by`: creator identity from authoritative item metadata. Do not substitute owner when creator is unavailable.
- `last_opened_by` and `last_opened_at`: populate only from authoritative audit/activity data. Do not infer from modified-by, recent-user, view count, synchronization, or access permissions.
- `last_modified_by`: authoritative last editor/modifier identity.
- `owner`: current owner or responsible account when returned by the repository.
- `sharing_exposure`: one of `private`, `internal`, `organization`, `specific external users`, `anonymous/public link`, `unknown`, or a repository-native equivalent.
- `external_sharing`: `true`, `false`, or `unknown`.
- Multiple values in one field must be semicolon-delimited.
- Missing values must be empty, except unavailable activity fields should use `not_available` when the connector cannot retrieve them and `not_authorized` when permissions are insufficient.
- `redacted_evidence` must follow the skill's redaction rules and must not include full government IDs, payment data, credentials, health details, or other raw sensitive values.
- CSV formula-injection protection is mandatory: if a textual field begins with `=`, `+`, `-`, `@`, tab, carriage return, or line feed, prefix it with a single quote.
- Normalize embedded line breaks to spaces and quote fields containing commas or quotes.

## Opened-by limitations

"File opened by" is generally activity/audit information, not ordinary file metadata.

- SharePoint/OneDrive: retrieve from authorized Microsoft 365 audit/activity sources when configured. Standard DriveItem metadata does not establish the last viewer.
- Google Drive: use authorized Drive Activity API or Workspace audit reports when available. A file's `viewedByMeTime` only describes the authenticated user's own view state and must not be labeled as the last viewer globally.
- Box: use authorized enterprise events or file-access event sources when available.
- Other repositories: require an audit/event API that identifies the actor and open/view/download event.

If audit access is absent, keep `last_opened_at` and `last_opened_by` as `not_available`; never guess.

## Report generation workflow

1. Build rows only from the completed scan result set.
2. Join audit/activity events by stable repository item ID and version where possible.
3. Deduplicate repeated events and select the latest authoritative open/view event.
4. Apply redaction and CSV-injection protection.
5. Validate the column count on every row.
6. Save as `sensitive-data-audit-YYYYMMDD-HHMMSSZ.csv`.
7. Return the file with a short summary of row count, repositories, unavailable fields, and scan limits.

## Optional summary CSV

When requested, generate a second CSV containing aggregate counts by repository, risk, data class, regulatory profile, sharing exposure, and remediation status. Do not combine summary and detail rows in one file.
