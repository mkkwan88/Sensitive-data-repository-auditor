# Repository connector contract

Every connector must use delegated or narrowly scoped authorization, expose stable item IDs and links, support pagination, and return content only for items inside approved roots.

## Common read actions

- List repositories, sites, drives, libraries, and folders available to the authenticated user.
- Search or enumerate items by approved root, modified date, MIME/type, and page token.
- Get item metadata: ID, name, path, owner, creator, modified time, size, MIME type, version/eTag, web link, parent, sharing exposure, and permissions summary.
- Export or download a supported version for text extraction.
- List versions where supported, but scan versions only when explicitly enabled.

## Common remediation actions

- Create/find a review folder inside the approved root.
- Apply a label, tag, category, or metadata classification.
- Move an item within the same repository and authorized boundary.
- Verify the resulting parent/classification/version.

Never delete, overwrite, alter sharing, break permission inheritance, publish, create public links, or change retention/legal-hold state by default.

## SharePoint and OneDrive

Suggested classification: existing Purview sensitivity label when the connector and policy permit it; otherwise a library column such as `Sensitive Data Review = Yes`.
Suggested folder: `Sensitive Data - Review`.

Minimum delegated scopes:
- Personal OneDrive owned files: `Files.Read` for discovery; `Files.ReadWrite` for approved remediation.
- Files the user can access across Microsoft 365: `Files.Read.All` or `Sites.Read.All`; remediation requires the corresponding write scope. Use broader scopes only when explicit scan scope requires them.

Actions should cover Graph drives/sites, DriveItem search, file download, list-item fields, permissions summary, move, and metadata update. Do not automatically assign Purview labels unless a supported, authorized labeling action is configured.

## Google Drive

Suggested label: `Sensitive Data Review` with values such as `Review Required`, `Reviewed`, and `False Positive`.
Suggested folder: `Sensitive Data - Review`.

For broad read discovery, use the narrowest viable Drive scope. `drive.file` only covers files created/opened with the app and is normally insufficient for an existing-drive audit. Broad `drive.readonly` or `drive` access can be restricted and may require verification/security assessment. Use Drive Labels API for structured classification where Workspace supports it.

Actions should cover files.list, files.get/export/download, permissions/list or exposure summary, labels/list/modify, and files.update for approved moves.

## Box

Suggested metadata template: `Sensitive Data Review` with fields `status`, `risk`, `profiles`, `reviewedAt`, and `reviewedBy`.
Suggested folder: `Sensitive Data - Review`.

Use OAuth 2.0 with `Read all files and folders` for discovery and `Read and write all files and folders` only for approved metadata or move actions. Effective access is the intersection of app scopes and authenticated-user permissions. Actions should cover search/list/get/download, collaborations/shared-link exposure, metadata instance creation/update, and move.

## Other repositories

Support connectors for Dropbox, Egnyte, Citrix ShareFile, OpenText, AWS S3, Azure Blob Storage, Google Cloud Storage, GitHub, GitLab, Atlassian Confluence, and other repositories only when all are true:

1. The user identifies an authorized root, project, bucket, container, space, or folder.
2. The connector supports least-privilege read access and stable IDs/version markers.
3. Text extraction is safe and bounded.
4. A reversible classification action exists, or remediation is report-only.
5. Public exposure and ACL data can be summarized without changing permissions.

Object stores require explicit account/project, bucket/container, and prefix. Source-code repositories require explicit organizations/projects/repos and must respect secret-scanning exclusions and binary/vendor directories.
