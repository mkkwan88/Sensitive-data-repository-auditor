# Source register

Review these authoritative sources before materially changing jurisdiction profiles:

- EU GDPR official text: https://eur-lex.europa.eu/eli/reg/2016/679/2016-05-04/eng
- US HHS HIPAA portal: https://www.hhs.gov/hipaa/index.html
- California Attorney General CCPA portal: https://www.oag.ca.gov/privacy/ccpa
- PCI DSS portal: https://www.pcisecuritystandards.org/standards/pci-dss/
- Office of the Privacy Commissioner of Canada, sensitive information: https://www.priv.gc.ca/en/privacy-topics/privacy-laws-in-canada/the-personal-information-protection-and-electronic-documents-act-pipeda/pipeda-compliance-help/pipeda-interpretation-bulletins/interpretations_10_sensible/
- Quebec private-sector privacy statute: https://www.legisquebec.gouv.qc.ca/en/document/cs/P-39.1
- Microsoft Graph mail API: https://learn.microsoft.com/en-us/graph/api/resources/mail-api-overview?view=graph-rest-1.0
- Microsoft Graph move message: https://learn.microsoft.com/en-us/graph/api/message-move?view=graph-rest-1.0
- Gmail OAuth scopes: https://developers.google.com/workspace/gmail/api/auth/scopes
- Gmail modify message: https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.messages/modify

Law and regulatory guidance change. Version jurisdiction profiles, record a review date, and revalidate them against primary sources before production compliance use.
